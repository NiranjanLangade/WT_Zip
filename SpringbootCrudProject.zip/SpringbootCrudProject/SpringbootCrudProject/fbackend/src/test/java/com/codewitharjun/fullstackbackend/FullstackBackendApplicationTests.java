package com.codewitharjun.fullstackbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
